//*************************************************//
//	Project 1											 							   //
//	Aaron Moton					        June 5th, 2016		 //
//	Luis Dominguez																 //
//*************************************************//

This program can be compiled by using the Makefile.
(Compile using: ~ make)

A file named LinkedLists will be created.
Run LinkedLists to run program. (i.e.Run using: ~ ./LinkedLists)

Main.cpp contains the menu to access both linked lists.
In the menus, there will be options that correspond to numbers.
Insert a number to select an option and press Enter.
Between the two linked lists, the user will be able to access
all of the functions in each of the Linked List classes.
